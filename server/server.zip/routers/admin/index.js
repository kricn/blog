const Router = require("koa-router");
const path = require("path");
const fs = require("await-fs");
const formidable = require("formidable");



//生成token
const guid = require("uuid/v4");

let router = new Router();


//登陆
router.post("/login", async ctx => {
	
	let {username, password} = ctx.request.fields;
	
	let rows = await ctx.db.query(`select * from users where username=?`, [username]);
	if(rows.length == 0){
		ctx.body = {err: 1, msg: 'no this user'}
	}else{
		let row = rows[0];

		if(row['password'] != password){
			ctx.body = {err: 1, msg: "password error"}
		}else{
			token = guid().replace(/\./g, "");
			let token_expires=Math.floor((Date.now()+ctx.config.TOKEN_AGE)/1000);

			await ctx.db.query('update users set token=?, token_expires=?', [token, token_expires]);
			ctx.body = {err: 0, token};
		}
	}
});

//主页
router.get('/home', async ctx => {
	let datas = await ctx.db.query(`select * from post`);

	let arr = [];

	datas.forEach(data => {
		arr.push(data);
	});

	ctx.body = arr;
	
});
//删除
router.get('/delete/:id', async ctx => {
	
	let {id} = ctx.params;

	await ctx.db.query(`update post set isDisplay=0 where id=?`, [id]);

	let datas = await ctx.db.query(`select * from post`);

	let arr = [];

	datas.forEach(data => {
		arr.push(data);
	});

	ctx.body = arr;
});
//恢复
router.get('/restore/:id', async ctx => {
	
	let {id} = ctx.params;

	await ctx.db.query(`update post set isDisplay=1 where id=?`, [id]);

	let datas = await ctx.db.query(`select * from post`);

	let arr = [];

	datas.forEach(data => {
		arr.push(data);
	});

	ctx.body = arr;
});

//发表
router.post('/create', async ctx => {
	
	let datas = ctx.request.body;

	let firstIndex = datas.indexOf(',');
	let lastIndex = datas.lastIndexOf(',')

	let title = datas.slice(0, firstIndex);

	let html = datas.slice(firstIndex+1, lastIndex);

	let date = datas.slice(lastIndex+1);

	await ctx.db.query(
		`insert into post (title,contents,date) value(?,?,?)`,
		[title, html, date]);

	ctx.body = {err: 0, msg: 'success'}
	
});

router.post('/upload', async ctx => {
	
	let url = path.basename(ctx.request.fields.image[0].path);
	console.log(url)
	await ctx.db.query(`insert into image_table (src) value(?)`, [url]);

	ctx.body = [url]

})

router.get('/upload', async ctx => {
	
	let url = await ctx.db.query(`select src from image_table`)

	console.log(url)

})

///////////////////////////////////////////////////////////////////////////

//取数据
router.get('/get', async ctx => {
	let datas = await ctx.db.query(`select * from post`);

	let arr = [];
	datas.forEach(data => {
		if(data.isDisplay){
			arr.push(data);
		}
	});
	ctx.body = arr
})

module.exports=router.routes();