const path = require('path');

module.exports={
	DB_HOST: 'localhost',
	DB_USER: 'blog',
	DB_PASS: 'blog',
	DB_NAME: 'blog',

	ADMIN_SUBFIX: '_,./!@#',

	PORT: 3000,

	HTTP_ROOT: 'http://134.175.241.15',

	UPLOAD_DIR: path.resolve(__dirname, './upload'),

	TOKEN_AGE : 14*86400*1000 
}